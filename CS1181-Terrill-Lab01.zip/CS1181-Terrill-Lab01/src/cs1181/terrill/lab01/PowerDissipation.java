/**
 * Interface to be implemented in order to determine power dissipation from 
 the voltage or current.
 */
package cs1181.terrill.lab01;

/**
 * @author Clayton Terrill 
 * CS1181L-06 
 * Instructor: R. Volkers 
 * TA: Sai Polamarasetty
 */
public interface PowerDissipation {
    /**
     * Empty interface method to provide a template for power dissipation
     from volts. Template for any class that implements the class.
     * Precondition: No predefined method template to determine power dissipation.
     * Postcondition: Method template that when overridden with proper code will
     determine the power dissipation from volts. 
     * @param volts - takes the amount of volts used to find power dissipation.
     * @return - returns the power dissipation amount
     * @throws Exception - allows exceptions to be defined later.
     */
    double powerFromVoltageDrop(double volts) throws Exception;

    /**
     * Empty interface method to provide a template for power dissipation
     from current. Template for any class that implements the class.
     * Precondition: No predefined method template to determine power dissipation.
     * Postcondition: Method template that when overridden with proper code will
     determine the power dissipation from current. 
     * @param current - takes the amount of current used to find power dissipation.
     * @return - returns the power dissipation amount.
     * @throws Exception - allows exceptions to be defined later.
     */
    double powerFromCurrentDraw(double current) throws Exception;
}

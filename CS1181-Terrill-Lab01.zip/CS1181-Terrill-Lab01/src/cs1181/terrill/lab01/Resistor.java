/**
 * Class to be called to create a Resistor object and use classes to further
 manipulate/ extend upon the object.
 */
package cs1181.terrill.lab01;

/**
 * @author Clayton Terrill 
 * CS1181L-06 
 * Instructor: R. Volkers 
 * TA: Sai Polamarasetty
 */
public class Resistor implements PowerDissipation {

    private double ohmsResistance;
    private double ohmsTolerance;
    private double powerRating;
    private double minResistance;
    private double maxResistance;
    private double voltagePowerDissipation;
    private double currentPowerDissipation;

    /**
     * Constructor for a resistor taking 3 parameters and testing to see if the
     input is valid.
     * Precondition: Objects can not be created and the class can not be accessed.
     * Postcondition: Objects may be created and methods within the class can be
     called with the object.
     * @param ohmsResistance - value greater than 0 that represents the resistance
     in ohms.
     * @param ohmsTolerance - value between 0 and 1 (not inclusive) that represents
     the tolerance in ohms.
     * @param powerRating - value greater than 0 that represents the power rating
     in watts.
     * @throws Exception - test to see if values entered are valid. If invalid 
     an IllegalArgumentException is thrown.
     */
    public Resistor(double ohmsResistance, double ohmsTolerance, double powerRating) throws Exception {
        if (ohmsResistance > 0) {
            this.ohmsResistance = ohmsResistance;
        } else {
            throw new IllegalArgumentException("ohmsResistance value must be greater than 0.");
        }
        if (ohmsTolerance > 0 && ohmsTolerance < 1) {
            this.ohmsTolerance = ohmsTolerance;
        } else {
            throw new IllegalArgumentException("ohmsTolerance value must be greater than 0 and less than 1.");
        }
        if (powerRating > 0) {
            this.powerRating = powerRating;
        } else {
            throw new IllegalArgumentException("powerRating value must be greater than 0.");
        }
    }

    /**
     * A getter that displays the value that ohmsResistance has.
     * @return the ohmsResistance
     */
    public double getOhmsResistance() {
        return ohmsResistance;
    }

    /**
     * A getter that displays the value that OhmsTolerance has.
     * @return the ohmsTolerance
     */
    public double getOhmsTolerance() {
        return ohmsTolerance;
    }

    /**
     * A getter that displays the value that PowerRating has.
     * @return the powerRating
     */
    public double getPowerRating() {
        return powerRating;
    }

    /**
     * Determines the minimum resistance present in the resistor based on
     ohmsResistance and ohmsTtolerance.
     * Precondition: Minimum resistance is undetermined and no resistance is 
     present.
     * Postcondition: Minimum resistance is defined and usable.
     * @return - returns the minimum resistance that can be displayed or used.
     */
    public double minResistance() {
        double localMinResistance = ohmsResistance - (ohmsResistance * ohmsTolerance);
        this.minResistance = localMinResistance;
        return this.minResistance;
    }

    /**
     * Determines the maximum resistance present in the resistor based on
     ohmsResistance and ohmsTtolerance.
     * Precondition: Maximum resistance is undetermined and no resistance is 
     present.
     * Postcondition: Maximum resistance is defined and usable.
     * @return - returns the maximum resistance that can be displayed or used.
     */
    public double maxResistance() {
        double localMaxResistance = ohmsResistance + (ohmsResistance * ohmsTolerance);
        this.maxResistance = localMaxResistance;
        return this.maxResistance;
    }

    /**
     * Determines the power dissipation based on voltage.
     * Precondition: Power dissipation is not considered.
     * Postcondition: Power dissipation is present and observed.
     * @param volts - user inputted volts is inputted to be used to determine
     the power dissipation.
     * @return - the voltage power dissipation to be displayed or used.
     * @throws Exception - throws exception if power dissipation exceeds the
     resistors power rating.
     */
    @Override
    public double powerFromVoltageDrop(double volts) throws Exception {
        double powerDissipation = volts * (volts / minResistance);
        if (powerDissipation < powerRating) {
            this.voltagePowerDissipation = powerDissipation;
            return this.voltagePowerDissipation;
        } else {
            throw new Exception("Power Dissipation exceeds the resistor's Power Rating.");
        }
    }

    /**
     * Determines the power dissipation based on current.
     * Precondition: Power dissipation is not considered.
     * Postcondition: Power dissipation is present and observed.
     * @param current - user inputted current is inputted to be used to determine
     the power dissipation.
     * @return - the current power dissipation to be displayed or used.
     * @throws Exception - throws exception if power dissipation exceeds the
     resistors power rating.
     */
    @Override
    public double powerFromCurrentDraw(double current) throws Exception {
        double powerDissipation = current * (current * maxResistance);
        if (powerDissipation < powerRating) {
            this.currentPowerDissipation = powerDissipation;
            return this.currentPowerDissipation;
        } else {
            throw new IllegalArgumentException("Power Dissapation exceeds the resistor's Power Rating.");
        }
    }

    /**
     * toString method that overrides the default toString in order to display
     the parameters in an ordered fashion.
     * Precondition: the original toString method is still being used and the 
     parameters can't be displayed.
     * Postcondition: Parameters are displayed in an ordered fashion.
     * @return - returns the string to be displayed.
     */
    @Override
    public String toString() {
        return "\nOhms Resistance: " + this.ohmsResistance
                + "\nOhms Tolerance: " + this.ohmsTolerance
                + "\nPower Rating: " + this.powerRating + "\n";
    }
}

/**
 * Class to be called to create a VariableResistor object and use classes to further
 manipulate/ extend upon the object.
 */
package cs1181.terrill.lab01;

/**
 * @author Clayton Terrill 
 * CS1181L-06 
 * Instructor: R. Volkers 
 * TA: Sai Polamarasetty
 */
public class VariableResistor extends Resistor {

    private double powerRating;
    private double controlSetting;
    private double minResistance;
    private double maxResistance;
    private double voltagePowerDissipation;
    private double currentPowerDissipation;

    /**
     * Constructor for a resistor taking 3 parameters and testing to see if the
     input is valid.
     * Precondition: Objects can not be created and the class can not be accessed.
     * Postcondition: Objects may be created and methods within the class can be
     called with the object.
     * @param ohmsResistance - value greater than 0 that represents the resistance
     in ohms.
     * @param ohmsTolerance - value between 0 and 1 (not inclusive) that represents
     the tolerance in ohms.
     * @param powerRating - value greater than 0 that represents the power rating
     in watts.
     * @param controlSetting - value between 0 and 1 (inclusive) that represents
     the control setting.
     * @throws Exception - test to see if values entered are valid. If invalid 
     an IllegalArgumentException is thrown. 
     */
    public VariableResistor(double ohmsResistance, double ohmsTolerance,
            double powerRating, double controlSetting) throws Exception {

        super(ohmsResistance, ohmsTolerance, powerRating);
        if (controlSetting>= 0 && controlSetting <= 1) {
            this.controlSetting = controlSetting;
        } else {
            throw new IllegalArgumentException("Control Setting value must "
                    + "be greater than or "
                    + "equal to 0 and less than or equal to 1.");
        }
    }

    /**
     * A getter that displays the value that control setting has.
     * @return the controlSetting
     */
    public double getControlSetting() {
        return controlSetting;
    }

    /**
     * A setter that can change the value of the control setting.
     * @param controlSetting the controlSetting to set
     * @throws java.lang.Exception - Control Setting value must be greater than or 
     equal to 0 and less than or equal to 1.
     */
    public void setControlSetting(double controlSetting) throws Exception {
        if (controlSetting>= 0 && controlSetting <= 1) {
            this.controlSetting = controlSetting;
        } else {
            throw new Exception("Control Setting value must be greater than or "
                    + "equal to 0 and less than or equal to 1.");
        }
    }
    
    /**
     * Determines the minimum resistance present in the resistor based on
     ohmsResistance and ohmsTtolerance.
     * Precondition: Minimum resistance is undetermined and no resistance is 
     present.
     * Postcondition: Minimum resistance is defined and usable.
     * @return - returns the minimum resistance that can be displayed or used.
     */
    @Override
    public double minResistance() {
        double localMinResistance = super.minResistance() * this.controlSetting;
        this.minResistance = localMinResistance;
        return this.minResistance;
    }

    /**
     * Determines the maximum resistance present in the resistor based on
     ohmsResistance and ohmsTtolerance.
     * Precondition: Maximum resistance is undetermined and no resistance is 
     present.
     * Postcondition: Maximum resistance is defined and usable.
     * @return - returns the maximum resistance that can be displayed or used.
     */
    @Override
    public double maxResistance() {
        double localMaxResistance = super.maxResistance() * this.controlSetting;
        this.maxResistance = localMaxResistance;
        return this.maxResistance;
    }
    
    /**
     * Determines the power dissipation based on voltage.
     * Precondition: Power dissipation is not considered.
     * Postcondition: Power dissipation is present and observed.
     * @param volts - user inputted volts is inputted to be used to determine
     the power dissipation.
     * @return - the voltage power dissipation to be displayed or used.
     * @throws Exception - throws exception if power dissipation exceeds the
     resistors power rating.
     */
    @Override
    public double powerFromVoltageDrop(double volts) throws Exception {
        double powerDissipation = volts * (volts / minResistance);
        if (powerDissipation < powerRating) {
            this.voltagePowerDissipation = powerDissipation;
            return this.voltagePowerDissipation;
        } else {
            throw new IllegalArgumentException("Power Dissapation exceeds the resistor's Power Rating.");
        }
    }

    /**
     * Determines the power dissipation based on current.
     * Precondition: Power dissipation is not considered.
     * Postcondition: Power dissipation is present and observed.
     * @param current - user inputted current is inputted to be used to determine
     the power dissipation.
     * @return - the current power dissipation to be displayed or used.
     * @throws Exception - throws exception if power dissipation exceeds the
     resistors power rating.
     */
    @Override
    public double powerFromCurrentDraw(double current) throws Exception {
        double powerDissipation = current * (current * maxResistance);
        if (powerDissipation < powerRating) {
            this.currentPowerDissipation = powerDissipation;
            return this.currentPowerDissipation;
        } else {
            throw new IllegalArgumentException("Power Dissapation exceeds the resistor's Power Rating.");
        }
    }
    
    /**
     * toString method that overrides the default toString in order to display
     the parameters in an ordered fashion.
     * Precondition: the original toString method is still being used and the 
     parameters can't be displayed.
     * Postcondition: Parameters are displayed in an ordered fashion.
     * @return - returns the string to be displayed.
     */ 
    @Override
    public String toString() {
        return super.toString() + "\nControl Setting: " + this.controlSetting;
    }
}

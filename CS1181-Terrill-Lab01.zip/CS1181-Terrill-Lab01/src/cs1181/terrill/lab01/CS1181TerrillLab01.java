/**
 * Test class to test resistor classes and the constructor/methods within them
 * Lab 1 for CS1181
 */
package cs1181.terrill.lab01;

/**
 * @author Clayton Terrill 
 * CS1181L-06 
 * Instructor: R. Volkers 
 * TA: Sai Polamarasetty
 */
public class CS1181TerrillLab01 {

    /**
     * Test class that tests each class and its methods to see if it works when
     it should work, and fail when it should fail.
     * Precondition: Classes are untested and are unproven to work.
     * Postcondition: Classes are tested and either confirmed to be correct, or
     confirmed to be incorrect.
     * @param args the command line arguments
     * @throws java.lang.Exception - the tests that fail throw an exception.
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here

        //resistance value in ohms which must be greater than 0
        //tolerance value expressed as a number between 0 and 1(not inclusive)
        //power rating expressed as some number of watts greater than 0
        //4 test objects that should work for Resistor class
        System.out.println("Following Four tests for the Resistor "
                + "Class should work properly: ");
        //test to see if values close to minimum work. Should work.
        try {
            Resistor testResistor1 = new Resistor(0.1, 0.1, 0.1);
            System.out.println("testResistor1 works properly");
        } catch (IllegalArgumentException e) {
            System.out.println("testResistor1 failed");
        }

        //test to see if large numbers, maximum numbers work. Should work
        try {
            Resistor testResistor2 = new Resistor(999999, 0.9, 999999);
            System.out.println("testResistor2 works properly");
        } catch (IllegalArgumentException e) {
            System.out.println("testResistor2 failed");
        }

        //test random numbers that should work
        try {
            Resistor testResistor3 = new Resistor(13, 0.8, 88);
            System.out.println("testResistor3 works properly");
        } catch (IllegalArgumentException e) {
            System.out.println("testResistor3 failed");
        }

        //test random numbers that should work
        try {
            Resistor testResistor4 = new Resistor(71, 0.008, 99);
            System.out.println("testResistor4 works properly");
        } catch (IllegalArgumentException e) {
            System.out.println("testResistor4 failed");
        }

        //test objects that should not work for Resistor class
        System.out.println("\n\nFollowing Seven tests for the Resistor Class should fail: ");
        //test to see if the not inclusive value(0) for resistance does not work. Should fail.
        try {
            Resistor testResistor5 = new Resistor(0, 0.1, 0.1);
            System.out.println("testResistor5 works properly");
        } catch (IllegalArgumentException e) {
            System.out.println("testResistor5 failed");
        }

        //test to see if not inclusive value(0) for tolerance does not work. Should fail.
        try {
            Resistor testResistor6 = new Resistor(0.1, 0, 0.1);
            System.out.println("testResistor6 works properly");
        } catch (IllegalArgumentException e) {
            System.out.println("testResistor6 failed");
        }

        //test to see if not inclusive value(1) for tolerance does not work. Should fail.
        try {
            Resistor testResistor7 = new Resistor(0.1, 1, 0.1);
            System.out.println("testResistor7 works properly");
        } catch (IllegalArgumentException e) {
            System.out.println("testResistor7 failed");
        }

        //test to see if not inclusive value(0) for power rating does not work. Should fail.
        try {
            Resistor testResistor8 = new Resistor(0.1, 0.1, 0);
            System.out.println("testResistor8 works properly");
        } catch (IllegalArgumentException e) {
            System.out.println("testResistor8 failed");
        }

        //test to see if negative value for resistance does not work. Should fail.
        try {
            Resistor testResistor9 = new Resistor(-0.1, 0.1, 0.1);
            System.out.println("testResistor9 works properly");
        } catch (IllegalArgumentException e) {
            System.out.println("testResistor9 failed");
        }

        //test to see if negative value for tolerance does not work. Should fail.
        try {
            Resistor testResistor10 = new Resistor(0.1, -0.1, 0.1);
            System.out.println("testResistor10 works properly");
        } catch (IllegalArgumentException e) {
            System.out.println("testResistor10 failed");
        }

        //test to see if negative value for power rating does not work. Should fail.
        try {
            Resistor testResistor11 = new Resistor(0.1, 0.1, -0.1);
            System.out.println("testResistor11 works properly");
        } catch (IllegalArgumentException e) {
            System.out.println("testResistor11 failed");
        }

        //resistance value in ohms which must be greater than 0
        //tolerance value expressed as a number between 0 and 1(not inclusive)
        //power rating expressed as some number of watts greater than 0
        //control setting can be varied from 0 to 1 inclusive.
        //4 test objects that should work for Resistor class
        System.out.println("\n\nFollowing Four tests for the VariableResistor "
                + "Class should work properly: ");

        //test to see if values close to minimum work. Should work.
        try {
            VariableResistor testVariableResistor12 = new VariableResistor(0.1, 0.1, 0.1, 0);
            System.out.println("testVariableResistor12 works properly");
        } catch (IllegalArgumentException e) {
            System.out.println("testVariableResistor12 failed");
        }

        //test to see if large numbers/ maximum numbers work. Should work
        try {
            VariableResistor testVariableResistor13 = new VariableResistor(999999, 0.9, 999999, 1);
            System.out.println("testVariableResistor13 works properly");
        } catch (IllegalArgumentException e) {
            System.out.println("testVariableResistor13 failed");
        }

        //test random numbers that should work
        try {
            VariableResistor testVariableResistor14 = new VariableResistor(13, 0.8, 88, 0.6);
            System.out.println("testVariableResistor14 works properly");
        } catch (IllegalArgumentException e) {
            System.out.println("testVariableResistor14 failed");
        }

        //test random numbers that should work
        try {
            VariableResistor testVariableResistor15 = new VariableResistor(71, 0.008, 99, 0.45);
            System.out.println("testVariableResistor15 works properly");
        } catch (IllegalArgumentException e) {
            System.out.println("testVariableResistor15 failed");
        }

        System.out.println("\n\nFollowing Nine tests for the VariableResistor Class should fail: ");
        //test to see if the not inclusive value(0) for resistance does not work. Should fail.
        try {
            VariableResistor testVariableResistor16 = new VariableResistor(0, 0.1, 0.1, 0);
            System.out.println("testVariableResistor16 works properly");
        } catch (IllegalArgumentException e) {
            System.out.println("testVariableResistor16 failed");
        }

        //test to see if not inclusive value(0) for tolerance does not work. Should fail.
        try {
            VariableResistor testVariableResistor17 = new VariableResistor(0.1, 0, 0.1, 0);
            System.out.println("testVariableResistor17 works properly");
        } catch (IllegalArgumentException e) {
            System.out.println("testVariableResistor17 failed");
        }

        //test to see if not inclusive value(1) for tolerance does not work. Should fail.
        try {
            VariableResistor testVariableResistor18 = new VariableResistor(0.1, 1, 0.1, 0);
            System.out.println("testVariableResistor18 works properly");
        } catch (IllegalArgumentException e) {
            System.out.println("testVariableResistor18 failed");
        }

        //test to see if not inclusive value(0) for power rating does not work. Should fail.
        try {
            VariableResistor testVariableResistor19 = new VariableResistor(0.1, 0.1, 0, 0);
            System.out.println("testVariableResistor19 works properly");
        } catch (IllegalArgumentException e) {
            System.out.println("testVariableResistor19 failed");
        }

        //test to see if negative value for resistance does not work. Should fail.
        try {
            VariableResistor testVariableResistor20 = new VariableResistor(-0.1, 0.1, 0.1, 0);
            System.out.println("testVariableResistor20 works properly");
        } catch (IllegalArgumentException e) {
            System.out.println("testVariableResistor20 failed");
        }

        //test to see if negative value for tolerance does not work. Should fail.
        try {
            VariableResistor testVariableResistor21 = new VariableResistor(0.1, -0.1, 0.1, 0);
            System.out.println("testVariableResistor21 works properly");
        } catch (IllegalArgumentException e) {
            System.out.println("testVariableResistor21 failed");
        }

        //test to see if negative value for power rating does not work. Should fail.
        try {
            VariableResistor testVariableResistor22 = new VariableResistor(0.1, 0.1, -0.1, 0);
            System.out.println("testVariableResistor22 works properly");
        } catch (IllegalArgumentException e) {
            System.out.println("testVariableResistor22 failed");
        }

        //test to see if negative value for power rating does not work. Should fail.
        try {
            VariableResistor testVariableResistor23 = new VariableResistor(0.1, 0.1, 0.1, -0.1);
            System.out.println("testVariableResistor23 works properly");
        } catch (IllegalArgumentException e) {
            System.out.println("testVariableResistor23 failed");
        }

        //test to see if value exceeding maximum value for power rating does not work. Should fail.
        try {
            VariableResistor testVariableResistor24 = new VariableResistor(0.1, 0.1, 0.1, 1.1);
            System.out.println("testVariableResistor24 works properly");
        } catch (IllegalArgumentException e) {
            System.out.println("testVariableResistor24 failed");
        }
        
        System.out.println("\n\nFollowing Four tests for the "
                + "Resistor.powerFromCurrentDraw "
                + "Class method should work properly: ");

        //test to see that the zero value for powerFromCurrentDraw produces 0 as output. Should work.
        try {
            Resistor testResistor25 = new Resistor(0.1, 0.1, 0.1);
            //after making sure original object is valid, this runs the test
            try {
                testResistor25.maxResistance();
                testResistor25.powerFromCurrentDraw(0);
                System.out.println("testResistor25.powerFromCurrentDraw "
                        + "works properly");
            } catch (IllegalArgumentException e) {
                System.out.println("testRresistor25.powerFromCurrentDraw failed.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("testResistor25.powerFromCurrentDraw failed");
        }
        
        //test to see that values that should work, work. Should work.
        try {
            Resistor testResistor26 = new Resistor(0.1, 0.1, 100);
            //after making sure original object is valid, this runs the test
            try {
                testResistor26.maxResistance();
                testResistor26.powerFromCurrentDraw(10);
                System.out.println("testResistor26.powerFromCurrentDraw "
                        + "works properly");
            } catch (IllegalArgumentException e) {
                System.out.println("testRresistor26.powerFromCurrentDraw failed.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("testResistor26.powerFromCurrentDraw failed");
        }
         
        //test to see that values that should work, work. Should work.
        try {
            Resistor testResistor27 = new Resistor(13, .30, 88);
            //after making sure original object is valid, this runs the test
            try {
                testResistor27.maxResistance(); 
                testResistor27.powerFromCurrentDraw(2);
                System.out.println("testResistor27.powerFromCurrentDraw "
                        + "works properly");
            } catch (IllegalArgumentException e) {
                System.out.println("testRresistor27.powerFromCurrentDraw failed.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("testResistor27.powerFromCurrentDraw failed");
        }
        
        //test to see if large values work properly. Should work.
        try {
            Resistor testResistor28 = new Resistor(22, 0.99, 1532);
            //after making sure original object is valid, this runs the test
            try {
                testResistor28.maxResistance();
                testResistor28.powerFromCurrentDraw(5);
                System.out.println("testResistor28.powerFromCurrentDraw "
                        + "works properly");
            } catch (IllegalArgumentException e) {
                System.out.println("testRresistor28.powerFromCurrentDraw failed.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("testResistor28.powerFromCurrentDraw failed");
        }
        
        System.out.println("\n\nFollowing Four tests for the "
                + "VariableResistor.powerFromCurrentDraw "
                + "Class method should work properly: ");

        //test to see that the zero value for powerFromCurrentDraw produces 0 as output. Should work.
        try {
            VariableResistor testVariableResistor29 = new VariableResistor(0.1, 0.1, 0.1, 10);
            //after making sure original object is valid, this runs the test
            try {
                testVariableResistor29.maxResistance();
                testVariableResistor29.powerFromCurrentDraw(0);
                System.out.println("testVariableResistor29.powerFromCurrentDraw "
                        + "works properly");
            } catch (IllegalArgumentException e) {
                System.out.println("testVariableResistor29.powerFromCurrentDraw failed ");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("testVariableResistor29.powerFromCurrentDraw failed");
        }
        
        //test to see that values that should work, work. Should work.
        try {
            VariableResistor testVariableResistor30 = new VariableResistor(0.1, 0.1, 100, 0);
            //after making sure original object is valid, this runs the test
            try {
                testVariableResistor30.maxResistance();
                testVariableResistor30.powerFromCurrentDraw(10);
                System.out.println("testVariableResistor30.powerFromCurrentDraw "
                        + "works properly");
            } catch (IllegalArgumentException e) {
                System.out.println("testVariableResistor30.powerFromCurrentDraw failed");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("testVariableResistor30.powerFromCurrentDraw failed");
        }
         
        //test to see that values that should work, work. Should work.
        try {
            VariableResistor testVariableResistor31 = new VariableResistor(13, .30, 88, 0);
            //after making sure original object is valid, this runs the test
            try {
                testVariableResistor31.maxResistance(); 
                testVariableResistor31.powerFromCurrentDraw(2);
                System.out.println("testVariableResistor31.powerFromCurrentDraw "
                        + "works properly");
            } catch (IllegalArgumentException e) {
                System.out.println("testVariableResistor31.powerFromCurrentDraw failed");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("testVariableResistor31.powerFromCurrentDraw failed");
        }
        
        //test to see if large values work properly. Should work.
        try {
            VariableResistor testVariableResistor32 = new VariableResistor(22, 0.99, 1532, 0);
            //after making sure original object is valid, this runs the test
            try {
                testVariableResistor32.maxResistance();
                testVariableResistor32.powerFromCurrentDraw(5);
                System.out.println("testVariableResistor32.powerFromCurrentDraw "
                        + "works properly");
            } catch (IllegalArgumentException e) {
                System.out.println("testVariableResistor32.powerFromCurrentDraw failed");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("testVariableResistor32.powerFromCurrentDraw failed");
        }
  
        System.out.println("\n\nFollowing Four tests for the "
                + "Resistor.powerFromCurrentDraw "
                + "Class method should fail: ");

        //test to see that the one value for powerFromCurrentDraw produces greater than minimmum power rating. Should fail.
        try {
            Resistor testResistor33 = new Resistor(0.1, 0.1, 0.1);
            //after making sure original object is valid, this runs the test
            try {
                testResistor33.maxResistance();
                testResistor33.powerFromCurrentDraw(1);
                System.out.println("testResistor33.powerFromCurrentDraw "
                        + "works properly");
            } catch (IllegalArgumentException e) {
                System.out.println("testRresistor33.powerFromCurrentDraw failed.");
            } 
        } catch (IllegalArgumentException e) {
            System.out.println("testResistor33.powerFromCurrentDraw failed");
        }
        
        //test to see that values that should fail, fail. Should fail.
        try {
            Resistor testResistor34 = new Resistor(0.1, 0.1, 100);
            //after making sure original object is valid, this runs the test
            try {
                testResistor34.maxResistance();
                testResistor34.powerFromCurrentDraw(50);
                System.out.println("testResistor34.powerFromCurrentDraw "
                        + "works properly");
            } catch (IllegalArgumentException e) {
                System.out.println("testRresistor34.powerFromCurrentDraw failed.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("testResistor34.powerFromCurrentDraw failed");
        }
         
        //test to see that values that should fail, fail. Should fail.
        try {
            Resistor testResistor35 = new Resistor(13, .30, 88);
            //after making sure original object is valid, this runs the test
            try {
                testResistor35.maxResistance(); 
                testResistor35.powerFromCurrentDraw(20);
                System.out.println("testResistor35.powerFromCurrentDraw "
                        + "works properly");
            } catch (IllegalArgumentException e) {
                System.out.println("testRresistor35.powerFromCurrentDraw failed.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("testResistor35.powerFromCurrentDraw failed");
        }
        
        //test to see if large values fail. Should fail.
        try {
            Resistor testResistor36 = new Resistor(22, 0.99, 1532);
            //after making sure original object is valid, this runs the test
            try {
                testResistor36.maxResistance();
                testResistor36.powerFromCurrentDraw(50005);
                System.out.println("testResistor36.powerFromCurrentDraw "
                        + "works properly");
            } catch (IllegalArgumentException e) {
                System.out.println("testRresistor36.powerFromCurrentDraw failed.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("testResistor36.powerFromCurrentDraw failed");
        }
    }//end main
}//end class

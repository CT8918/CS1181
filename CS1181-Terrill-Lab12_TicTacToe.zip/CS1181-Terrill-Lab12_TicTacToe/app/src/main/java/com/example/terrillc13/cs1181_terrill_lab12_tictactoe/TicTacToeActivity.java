package com.example.terrillc13.cs1181_terrill_lab12_tictactoe;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * A Tic-Tac-Toe game made by Clayton Terrill.
 */
public class TicTacToeActivity extends AppCompatActivity {

    //the status TextView
    private TextView statusMessage;
    //status to be displayed
    private String statusString;

    //the buttons for th game
    private Button topLeftButton;
    private Button topCenterButton;
    private Button topRightButton;
    private Button middleLeftButton;
    private Button middleCenterButton;
    private Button middleRightButton;
    private Button bottomLeftButton;
    private Button bottomCenterButton;
    private Button bottomRightButton;

    //determines how many times button has been pressed
    private int tlb;
    private int tcb;
    private int trb;
    private int mlb;
    private int mcb;
    private int mrb;
    private int blb;
    private int bcb;
    private int brb;

    //creates an array of the contents of each button
    private String[] ticTacToeBoard = new String[9];

    //current player selecting
    private String player;

    //players
    private String playerX = "X";
    private String playerO  = "O";


    //private String nameX, nameO;

    //the TextViews of the scores
    private TextView playerXScore;
    private TextView playerOScore;
    private TextView tiedScore;

    //the number of wins and draws to be shown
    private int XScore = 0;
    private int OScore = 0;
    private int XOScore = 0;

    //log string for debugging
    private String TAG = "ticTacToeLogs";

    private String gameMode = "2players";
    //determines if the game is over or not
    private boolean gameOver;

    //selects Game Mode
    private Button twoPlayerButton;
    private Button computerButton;

    /**
     * Runs as soon as the app is started. Initializes everything and sets up the start.
     * @param savedInstanceState - not used.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tic_tac_toe);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Log.i(TAG, "In OnCreate");

        statusMessage = (TextView) findViewById(R.id.newStatusMessage);
        playerXScore = (TextView) findViewById(R.id.playerXScore);
        playerOScore = (TextView) findViewById(R.id.playerOScore);
        tiedScore = (TextView) findViewById(R.id.tiedScore);

        topLeftButton = (Button) findViewById(R.id.topLeftButton);
        topCenterButton = (Button) findViewById(R.id.topCenterButton);
        topRightButton = (Button) findViewById(R.id.topRightButton);
        middleLeftButton = (Button) findViewById(R.id.middleLeftButton);
        middleCenterButton = (Button) findViewById(R.id.middleCenterButton);
        middleRightButton = (Button) findViewById(R.id.middleRightButton);
        bottomLeftButton = (Button) findViewById(R.id.bottomLeftButton);
        bottomCenterButton = (Button) findViewById(R.id.bottomCenterButton);
        bottomRightButton = (Button) findViewById(R.id.bottomRightButton);

        twoPlayerButton = (Button) findViewById(R.id.twoPlayerButton);
        computerButton = (Button) findViewById(R.id.computerButton);

        //initial state of game
        twoPlayerButton.setEnabled(false);
        computerButton.setEnabled(true);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        //creates a new game
        newGame();
    }

    /**
     * starts a new game by resetting everything, but the score, back to its initial state.
     */
    private void newGame() {
        Log.i(TAG, "In newGame");

        playerX = "X";
        playerO = "O";

        topLeftButton.setEnabled(true);
        topCenterButton.setEnabled(true);
        topRightButton.setEnabled(true);
        middleLeftButton.setEnabled(true);
        middleCenterButton.setEnabled(true);
        middleRightButton.setEnabled(true);
        bottomLeftButton.setEnabled(true);
        bottomCenterButton.setEnabled(true);
        bottomRightButton.setEnabled(true);

        topLeftButton.setText("");
        topCenterButton.setText("");
        topRightButton.setText("");
        middleLeftButton.setText("");
        middleCenterButton.setText("");
        middleRightButton.setText("");
        bottomLeftButton.setText("");
        bottomCenterButton.setText("");
        bottomRightButton.setText("");

        tlb = 0;
        tcb = 0;
        trb = 0;
        mlb = 0;
        mcb = 0;
        mrb = 0;
        blb = 0;
        bcb = 0;
        brb = 0;

        player = "X";

        statusString = "Player " + player + "'s turn";
        statusMessage.setText(statusString);

        gameOver = false;

        //resets the board to blank
        for (int i = 0; i < 9; i++) {
            ticTacToeBoard[i] = "";
        }
    }

    /**
     * Just an options item. No use in program.
     * @param menu - menu menu
     * @return - true or false.
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_tic_tac_toe, menu);
        return true;
    }

    /**
     * Just an options item. No use in program.
     * @param item - menu item
     * @return - true or false.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * Corresponding button is clicked and runs methods to set value to the proper position.
     * @param view - button.
     */
    public void topLeftButtonClicked(View view) {
        Log.i(TAG, "In topLeftButtonClicked");
        tlb++;
        if(tlb ==1) {
            //position 0
            ticTacToeBoard[0] = player;
            displayButtonText(topLeftButton);
            checkForWinner();
            if(gameMode == "2players") {
                changeTurns();
            }
            if(gameMode == "computer"){
                computerMove();
                checkForWinner();
            }
        }else{
            Toast t = Toast.makeText(this, "That square is already taken", Toast.LENGTH_SHORT);
            t.show();
            //for trollers
            topLeftButton.setEnabled(false);
        }
    }

    /**
     * Corresponding button is clicked and runs methods to set value to the proper position.
     * @param view - button.
     */
    public void topCenterButtonClicked(View view) {
        Log.i(TAG, "In topCenterButtonClicked");
        tcb++;
        if(tcb == 1) {
            //position 1
            ticTacToeBoard[1] = player;
            displayButtonText(topCenterButton);
            checkForWinner();
            if(gameMode == "2players") {
                changeTurns();
            }
            if(gameMode == "computer"){
                computerMove();
                checkForWinner();
            }
        }else{
            Toast t = Toast.makeText(this, "That square is already taken", Toast.LENGTH_SHORT);
            t.show();
            //for trollers
            topCenterButton.setEnabled(false);
        }
    }

    /**
     * Corresponding button is clicked and runs methods to set value to the proper position.
     * @param view - button.
     */
    public void topRightButtonClicked(View view) {
        Log.i(TAG, "In topRightButtonClicked");
        trb++;
        if(trb==1) {
            //position 2
            ticTacToeBoard[2] = player;
            displayButtonText(topRightButton);
            checkForWinner();
            if(gameMode == "2players") {
                changeTurns();
            }
            if(gameMode == "computer"){
                computerMove();
                checkForWinner();
            }
        }else{
            Toast t = Toast.makeText(this, "That square is already taken", Toast.LENGTH_SHORT);
            t.show();
            //for trollers
            topRightButton.setEnabled(false);
        }
    }

    /**
     * Corresponding button is clicked and runs methods to set value to the proper position.
     * @param view - button.
     */
    public void middleLeftButtonClicked(View view) {
        Log.i(TAG, "In middleLeftButtonClicked");
        mlb++;
        if(mlb==1) {
            //position 3
            ticTacToeBoard[3] = player;
            displayButtonText(middleLeftButton);
            checkForWinner();
            if(gameMode == "2players") {
                changeTurns();
            }
            if(gameMode == "computer"){
                computerMove();
                checkForWinner();
            }
        }else{
            Toast t = Toast.makeText(this, "That square is already taken", Toast.LENGTH_SHORT);
            t.show();
            //for trollers
            middleLeftButton.setEnabled(false);
        }
    }

    /**
     * Corresponding button is clicked and runs methods to set value to the proper position.
     * @param view - button.
     */
    public void middleCenterButtonClicked(View view) {
        Log.i(TAG, "In middleCenterButtonClicked");
        mcb++;
        if(mcb==1) {
            //position 4
            ticTacToeBoard[4] = player;
            displayButtonText(middleCenterButton);
            checkForWinner();
            if(gameMode == "2players") {
                changeTurns();
            }
            if(gameMode == "computer"){
                computerMove();
                checkForWinner();
            }
        }else{
            Toast t = Toast.makeText(this, "That square is already taken", Toast.LENGTH_SHORT);
            t.show();
            //for trollers
            middleCenterButton.setEnabled(false);
        }
    }

    /**
     * Corresponding button is clicked and runs methods to set value to the proper position.
     * @param view - button.
     */
    public void middleRightButtonClicked(View view) {
        Log.i(TAG, "In middleRightButtonClicked");
        mrb++;
        if(mrb==1) {
            //position 5
            ticTacToeBoard[5] = player;
            displayButtonText(middleRightButton);
            checkForWinner();
            if(gameMode == "2players") {
                changeTurns();
            }
            if(gameMode == "computer"){
                computerMove();
                checkForWinner();
            }
        }else{
            Toast t = Toast.makeText(this, "That square is already taken", Toast.LENGTH_SHORT);
            t.show();
            //for trollers
            middleRightButton.setEnabled(false);
        }
    }

    /**
     * Corresponding button is clicked and runs methods to set value to the proper position.
     * @param view - button.
     */
    public void bottomLeftButtonClicked(View view) {
        Log.i(TAG, "In bottomLeftButtonClicked");
        blb++;
        if(blb==1) {
            //position 6
            ticTacToeBoard[6] = player;
            displayButtonText(bottomLeftButton);
            checkForWinner();
            if(gameMode == "2players") {
                changeTurns();
            }
            if(gameMode == "computer"){
                computerMove();
                checkForWinner();
            }
        }else{
            Toast t = Toast.makeText(this, "That square is already taken", Toast.LENGTH_SHORT);
            t.show();
            //for trollers
            bottomLeftButton.setEnabled(false);
        }
    }

    /**
     * Corresponding button is clicked and runs methods to set value to the proper position.
     * @param view - button.
     */
    public void bottomCenterButtonClicked(View view) {
        Log.i(TAG, "In bottomCenterButtonClicked");
        bcb++;
        if(bcb==1) {
            //position 7
            ticTacToeBoard[7] = player;
            displayButtonText(bottomCenterButton);
            checkForWinner();
            if(gameMode == "2players") {
                changeTurns();
            }
            if(gameMode == "computer"){
                computerMove();
                checkForWinner();
            }
        }else{
            Toast t = Toast.makeText(this, "That square is already taken", Toast.LENGTH_SHORT);
            t.show();
            //for trollers
            bottomCenterButton.setEnabled(false);
        }
    }

    /**
     * Corresponding button is clicked and runs methods to set value to the proper position.
     * @param view - button.
     */
    public void bottomRightButtonClicked(View view) {
        Log.i(TAG, "In bottomRightButtonClicked");
        brb++;
        if(brb==1) {
            //position 8
            ticTacToeBoard[8] = player;
            displayButtonText(bottomRightButton);
            checkForWinner();
            if(gameMode == "2players") {
                changeTurns();
            }
            if(gameMode == "computer"){
                computerMove();
                checkForWinner();
            }
        }else{
            Toast t = Toast.makeText(this, "That square is already taken", Toast.LENGTH_SHORT);
            t.show();
            //for trollers
            bottomRightButton.setEnabled(false);
        }
    }

    /**
     * Sets the text on the button to its correct value and color.
     * @param button - button.
     */
    public void displayButtonText(Button button){
        Log.i(TAG, "In displayButtonText");
        String text = "";

        if (player == playerX){
            button.setTextColor(Color.RED);
            text = "X";
        }
        else if (player == playerO){
            button.setTextColor(Color.BLUE);
            text = "O";
        }
        button.setText(text);
    }

    /**
     * Checks for a winner after every move.
     */
    private void checkForWinner() {
        boolean XWinner = false,
                OWinner = false,
                draw = false;

        //check to see if X won

        //these 3 check for across
        if (ticTacToeBoard[0] == "X" &&  ticTacToeBoard[1] == "X" && ticTacToeBoard[2] == "X") {
            XWinner = true;
        }
        if (ticTacToeBoard[3] == "X" &&  ticTacToeBoard[4] == "X" && ticTacToeBoard[5] == "X") {
            XWinner = true;
        }
        if (ticTacToeBoard[6] == "X" &&  ticTacToeBoard[7] == "X" && ticTacToeBoard[8] == "X") {
            XWinner = true;
        }

        //these 3 check for down
        if (ticTacToeBoard[0] == "X" &&  ticTacToeBoard[3] == "X" && ticTacToeBoard[6] == "X") {
            XWinner = true;
        }
        if (ticTacToeBoard[1] == "X" &&  ticTacToeBoard[4] == "X" && ticTacToeBoard[7] == "X") {
            XWinner = true;
        }
        if (ticTacToeBoard[2] == "X" &&  ticTacToeBoard[5] == "X" && ticTacToeBoard[8] == "X") {
            XWinner = true;
        }
        //these 2 check for diagonal
        if (ticTacToeBoard[0] == "X" &&  ticTacToeBoard[4] == "X" && ticTacToeBoard[8] == "X") {
            XWinner = true;
        }
        if (ticTacToeBoard[2] == "X" &&  ticTacToeBoard[4] == "X" && ticTacToeBoard[6] == "X") {
            XWinner = true;
        }

        //check to see if O won

        //these 3 check for across
        if (ticTacToeBoard[0] == "O" &&  ticTacToeBoard[1] == "O" && ticTacToeBoard[2] == "O") {
            OWinner = true;
        }
        if (ticTacToeBoard[3] == "O" &&  ticTacToeBoard[4] == "O" && ticTacToeBoard[5] == "O") {
            OWinner = true;
        }
        if (ticTacToeBoard[6] == "O" &&  ticTacToeBoard[7] == "O" && ticTacToeBoard[8] == "O") {
            OWinner = true;
        }

        //these 3 check for down
        if (ticTacToeBoard[0] == "O" &&  ticTacToeBoard[3] == "O" && ticTacToeBoard[6] == "O") {
            OWinner = true;
        }
        if (ticTacToeBoard[1] == "O" &&  ticTacToeBoard[4] == "O" && ticTacToeBoard[7] == "O") {
            OWinner = true;
        }
        if (ticTacToeBoard[2] == "O" &&  ticTacToeBoard[5] == "O" && ticTacToeBoard[8] == "O") {
            OWinner = true;
        }
        //these 2 check for diagonal
        if (ticTacToeBoard[0] == "O" &&  ticTacToeBoard[4] == "O" && ticTacToeBoard[8] == "O") {
            OWinner = true;
        }
        if (ticTacToeBoard[2] == "O" &&  ticTacToeBoard[4] == "O" && ticTacToeBoard[6] == "O") {
            OWinner = true;
        }

        if (XWinner) {
            draw = false;
            statusString = "PlayerX WINS! New game in 3 seconds.";
            XScore++;
            String scoreX = Integer.toString(XScore);
            playerXScore.setText(scoreX);
        }
        else if(OWinner){
            draw = false;
            statusString = "PlayerO WINS! New game in 3 seconds.";
            OScore++;
            String scoreO = Integer.toString(OScore);
            playerOScore.setText(scoreO);
        }
        else {
            int filled = 0;
            for (int i = 0; i < 9; i++) {
                if (ticTacToeBoard[i] == "X" || ticTacToeBoard[i] == "O") {
                    filled++;
                }
            }
            if (filled == 9) {
                draw = true;
            }
            if (draw && !OWinner && !XWinner) {
                statusString = "Game is a draw. New game in 3 seconds.";
                XOScore++;
                String scoreXO = Integer.toString(XOScore);
                tiedScore.setText(scoreXO);
            }
        }
        if (XWinner || OWinner || draw) {
            gameOver = true;
            int numberOfGames = XScore + OScore + XOScore;
            statusMessage.setText("Game " + numberOfGames + " Finished" );
            Toast t = Toast.makeText(this, statusString, Toast.LENGTH_SHORT);
            t.show();
        } else {
            gameOver = false;
        }
    }

    /**
     * Changes the user turns or starts new game if game is won.
     */
    public void changeTurns(){

        if(!gameOver) {
            //change turns
            if (player.equalsIgnoreCase(playerX)) {
                player = playerO;
            } else {
                player = playerX;
            }
            statusString = "Player " + player + "'s turn";
            statusMessage.setText(statusString);
        }else{
            topLeftButton.setEnabled(false);
            topCenterButton.setEnabled(false);
            topRightButton.setEnabled(false);
            middleLeftButton.setEnabled(false);
            middleCenterButton.setEnabled(false);
            middleRightButton.setEnabled(false);
            bottomLeftButton.setEnabled(false);
            bottomCenterButton.setEnabled(false);
            bottomRightButton.setEnabled(false);

            //delays the start of a new game for 3 seconds
            Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    newGame();
                }
            }, 3000);
        }
    }

    /**
     * The computer makes a basic random move.
     */
    public void computerMove() {
        try {
            statusString = "Computer's turn";
            statusMessage.setText(statusString);
            if (!gameOver) {
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        boolean valid = false;
                        int move = -1;
                        while (!valid) {
                            move = (int) (Math.random() * 9);
                            if (ticTacToeBoard[move] != "X" && ticTacToeBoard[move] != "O") {
                                valid = true;
                            }
                        }
                        ticTacToeBoard[move] = "O";
                        if (move == 0) {
                            topLeftButton.setTextColor(Color.BLUE);
                            topLeftButton.setText("O");
                            topLeftButton.setEnabled(false);
                        }
                        if (move == 1) {
                            topCenterButton.setTextColor(Color.BLUE);
                            topCenterButton.setText("O");
                            topCenterButton.setEnabled(false);
                        }
                        if (move == 2) {
                            topRightButton.setTextColor(Color.BLUE);
                            topRightButton.setText("O");
                            topRightButton.setEnabled(false);
                        }
                        if (move == 3) {
                            middleLeftButton.setTextColor(Color.BLUE);
                            middleLeftButton.setText("O");
                            middleLeftButton.setEnabled(false);
                        }
                        if (move == 4) {
                            middleCenterButton.setTextColor(Color.BLUE);
                            middleCenterButton.setText("O");
                            middleCenterButton.setEnabled(false);
                        }
                        if (move == 5) {
                            middleRightButton.setTextColor(Color.BLUE);
                            middleRightButton.setText("O");
                            middleRightButton.setEnabled(false);
                        }
                        if (move == 6) {
                            bottomLeftButton.setTextColor(Color.BLUE);
                            bottomLeftButton.setText("O");
                            bottomLeftButton.setEnabled(false);
                        }
                        if (move == 7) {
                            bottomCenterButton.setTextColor(Color.BLUE);
                            bottomCenterButton.setText("O");
                            bottomCenterButton.setEnabled(false);
                        }
                        if (move == 8) {
                            bottomRightButton.setTextColor(Color.BLUE);
                            bottomRightButton.setText("O");
                            bottomRightButton.setEnabled(false);
                        }
                        statusString = "Player " + player + "'s turn";
                        statusMessage.setText(statusString);
                    }
                }, 2000);
                checkForWinner();
            } else {
                topLeftButton.setEnabled(false);
                topCenterButton.setEnabled(false);
                topRightButton.setEnabled(false);
                middleLeftButton.setEnabled(false);
                middleCenterButton.setEnabled(false);
                middleRightButton.setEnabled(false);
                bottomLeftButton.setEnabled(false);
                bottomCenterButton.setEnabled(false);
                bottomRightButton.setEnabled(false);

                //delays the start of a new game for 3 seconds
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        newGame();
                    }
                }, 3000);
            }
        } catch(Exception e){
        }
    }

    /**
     * default debugging.
     */
    @Override
    protected void onStop() {
        super.onStop();
        Log.i(TAG, "In OnStop");
    }

    /**
     * default debugging.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "In OnDestroy");
    }

    /**
     * default debugging.
     */
    @Override
    protected void onPause() {
        super.onPause();
        Log.i(TAG, "In OnPause");
    }

    /**
     * default debugging.
     */
    @Override
    protected void onResume() {
        super.onResume();
        Log.i(TAG, "In OnResume");
    }

    /**
     * default debugging.
     */
    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i(TAG, "In OnRestart");
    }

    /**
     * default debugging.
     */
    @Override
    protected void onStart() {
        super.onStart();
        Log.i(TAG, "In OnStart");
    }

    /**
     * default debugging.
     */
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.i(TAG, "In OnSaveInstanceState");
    }

    /**
     * default debugging.
     */
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Log.i(TAG, "In OnRestoreInstanceState");
    }

    /**
     * Resets the games scores.
     * @param view
     */
    public void newGameButtonClicked(View view) {
        Log.i(TAG, "In newGameButtonClicked - Game Reset");
        newGame();
        XScore = 0;
        OScore = 0;
        XOScore = 0;
        String scoreX = Integer.toString(XScore);
        playerXScore.setText(scoreX);
        String scoreO = Integer.toString(OScore);
        playerOScore.setText(scoreO);
        String scoreXO = Integer.toString(XOScore);
        tiedScore.setText(scoreXO);
    }

    /**
     * Plays the two player mode built into the game.
     * @param view
     */
    public void twoPlayerClicked(View view) {
        Log.i(TAG, "In twoPlayerClicked - Game Reset");
        twoPlayerButton.setEnabled(false);
        computerButton.setEnabled(true);

        gameMode = "2players";

        newGame();
        XScore = 0;
        OScore = 0;
        XOScore = 0;
        String scoreX = Integer.toString(XScore);
        playerXScore.setText(scoreX);
        String scoreO = Integer.toString(OScore);
        playerOScore.setText(scoreO);
        String scoreXO = Integer.toString(XOScore);
        tiedScore.setText(scoreXO);
    }

    /**
     * Plays the versus computer mode built into the game.
     * @param view
     */
    public void computerClicked(View view) {
        Log.i(TAG, "In computerClicked - Game Reset");
        twoPlayerButton.setEnabled(true);
        computerButton.setEnabled(false);

        gameMode = "computer";

        newGame();
        XScore = 0;
        OScore = 0;
        XOScore = 0;
        String scoreX = Integer.toString(XScore);
        playerXScore.setText(scoreX);
        String scoreO = Integer.toString(OScore);
        playerOScore.setText(scoreO);
        String scoreXO = Integer.toString(XOScore);
        tiedScore.setText(scoreXO);
    }
}

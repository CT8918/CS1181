/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cs1181.terrill.lab09;

/**
 *
 * @author Clayton Terrill
 */
public class CS1181TerrillLab09 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        SearchDemo search = new SearchDemo();
        search.initializeArray(100);
        System.out.println("Array: \n" + search.toString());
        search.shellSort();
        System.out.println("Sorted Array: \n" + search.toString());
    }
    
}

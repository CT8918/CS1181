/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cs1181.terrill.lab09;

import java.util.Random;

/**
 *
 * @author Ecslogon2
 */
public class SearchDemo {

    private double[] aob;
    private Random ron = new Random();

    public void SearchDemo() {

    }

    public void initializeArray(int arraySize) {

        //initializes the aob array to a certain size.
        aob = new double[arraySize];

        //fills the array with random values
        for (int i = 0; i < arraySize; i++) {

            //generates a random number between 0 and 10 * arraySize with decimals.
            double generatedNumber = 0 + (10 * arraySize - 0) * ron.nextDouble();

            //rounds number to tenths place.
            double roundedGeneratedNumber
                    = Math.round(generatedNumber * 10.0) / 10.0;

            //assigns the properly rounded random number to an available spot in the array.
            aob[i] = roundedGeneratedNumber;
        }
    }

    /**
     * Prints the aob arrays current state with 6 values per line and commas 
     * separating the values.
     * Precondition - array must be initialized and filled, means that
     * initializeArray must have been ran already. 
     * Postcondition - the current values in each location of the array
     * are now displayed.
     * @return - a formatted String of the values within the array.
     */
    @Override
    public String toString() {
        //prints the array through a loop.
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < aob.length; i++) {

            if(i==0){
                sb.append(aob[i]);
                sb.append(", ");
            }
            //after every 6 values a new line is created. 6 values per line.
            else if (i % 6 == 0 && i != 0) {
                sb.append("\n");
                sb.append(aob[i]);
                sb.append(", ");
                //System.out.println("");
            }
            else if(aob[i] < 10){
                sb.append("  " + aob[i]);
                sb.append(", ");
            }
            //if the last number of array is reached, don't print comma after it.
            else if(i == aob.length-1) {
                //prints out current value in array without comma afterwards.
                sb.append(aob[i]);
                sb.append("\n");
                //System.out.print(aob[i] + "\n");
            } 
            //if not last number, then a comma is printed afterwards.
            else {
                //prints out current value in array with comma and space afterwards.
                sb.append(aob[i]);
                sb.append(", ");
                //System.out.print(aob[i] + ", ");
            }

        }
        return sb.toString();//returns the formatted String.
    }

    public void shellSort() {
        //create pointer in the middle of array.
        int ptr = aob.length / 2;
        //runs while there are still numbers to be sorted.
        while (ptr > 0) {
            for (int i = 0; i < (aob.length - ptr); i++) {
                int j = i;//copies value of i to j for use in a loop within a loop.
                //runs until beginning of array is reached or if current number is more than the next.
                while (j >= 0 && aob[j] > aob[j + ptr]) {
                    //rearranges the values accordingly.
                    double tempNumber = aob[j];//holds number to be sorted.
                    aob[j] = aob[j + ptr];//number after the current.
                    aob[j + ptr] = tempNumber;//switches the numbers.
                    j--;//subtracts value of j until beginning is reached.
                }
            }
            ptr = ptr / 2;//makes the pointer move to next value to be sorted.
        }
    }
}

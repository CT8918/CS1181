/*
 * Created Linked List from scratch that demonstrates how Nodes work.
 */
package cs1181.terrill.lab02;

/**
 * @author Clayton Terrill 
 * CS1181L-06 
 * Instructor: R. Volkers 
 * TA: Sai Polamarasetty
 */
public class OrderedLinkedList {

    private class Node {

        public String payload;
        public int keyValue;
        public Node next;

        public Node(String payload, int value) {
            this.payload = payload;
            this.keyValue = value;
        }
    }
    private Node first;

    /**
     * Default Constructor for the Linked List that puts a default node in;
     * Precondition: No nodes are present and no nodes can be put in.
     * Postcondition: A default node is present and nodes can be put in.
     */
    public OrderedLinkedList() {
        first = new Node(null, 0);
    }

    /**
     * Determines if the linked list is empty or not. Returns a variable that
     * may be used to display if empty or determine if empty in other methods.
     * Precondition: Unknown if linked list is empty. 
     * Postcondition: A boolean value is present describing the condition
       of the linked list.
     * @return - true if empty. False if at least one node is present.
     */
    public boolean empty() {
        int empty = listCount();
        if(empty < 1){
            return true;
        }
        else{
            return false;
        }
    }

    /**
     * Gets the first value of the linked list, returns the String, and then
     * removes it from the list. 
     * Precondition: The lists is fully intact.
     * Postcondition: The first value from the linked list is returned as a
       string and then removed from list.
     * @return - the removed nodes payload.
     * @throws Exception - throws an exception if first node is empty.
     */
    public String getFirst() throws Exception {
        Node removedNode = first;//the default first node to be used
        if (first == null) {
            throw new Exception("The First Node Is Empty");
        } else {
            Node displayNode = removedNode;
            removedNode = removedNode.next;
            removedNode.next = null;

            return removedNode.payload;
        }

    }

    /**
     * Gets the last value of the linked list, returns the String, and then
     * removes it from the list. 
     * Precondition: The lists is fully intact.
     * Postcondition: The last value from the linked list is returned as a
     * string and then removed from list.
     * @return - the removed nodes payload.
     * @throws Exception - throws an exception if first node is empty.
     */
    public String getLast() throws Exception {
        if (first == null) {
            throw new Exception("The List has no start");
        } else {
            Node removedNode = first;//the default first node to be used
            Node previous = null;//node to be used later

            while (removedNode.next != null) {
                previous = removedNode;
                removedNode = removedNode.next;
            }

            previous.next = null;
            return removedNode.payload;
        }
    }

    /**
     * Inserts a node at a specified key value.
     * Precondition: the lists has the nodes currently in it.
     * Postcondition: the lists has the nodes currently in it plus the 
       node that was inserted.
     * @param payload - the string that is within the node.
     * @param key - the designated position of the node.
     * @throws Exception - throws an exception if key value is already used,
     */
    public void insert(String payload, int key) throws Exception {
        Node checkNode = first;//the default first node to be used
        while (checkNode.next != null) {
            if (checkNode.keyValue == key) {
                throw new Exception("key already used");
            }
            checkNode = checkNode.next;

        }
        Node newNode = new Node(payload, key);
        Node current = first;//the default first node to be used
        //loop to go to requested key value or go to end of list.
        for (int i = 1; i < key && current.next != null; i++) {
            current = current.next;
        }

        //sets newNodes pointer to currentNodes next node.
        newNode.next = current.next;
        //sets current Nodes pointer to the newNode.
        current.next = newNode;

    }

    /**
     * Removes the node at the designated position. 
     * Precondition: The list is as it was. 
     * Postcondition: the list is as it was minus the node with the key
       value that was specified.
     * @param key - designates what position should be deleted.
     * @throws Exception - throws Exception if key is not found.
     */
    public void remove(int key) throws Exception {
        //throws an exception if key is out of bounds
        if (key < 1 || key > listCount()) {
            throw new Exception("key out of bounds");
        }
        Node current = first;//the default first node to be used
        for (int i = 1; i < key; i++) {
            if (current.next == null) {
                throw new Exception("key does not exist");
            }
            current = current.next;
        }
        current.next = current.next.next;
    }

    /**
     * Counts to see how many nodes are within the list. 
     * Precondition: how many nodes present is undetermined. 
     * Postcondition: how many nodes present has been determined and may 
       be used either as a display or in other methods.
     * @return - the amount of nodes in the list.
     */
    public int listCount() {
        int count = 0;
        Node current = this.first;//the default first node to be used
        while (current != null) {
            count++;
            current = current.next;
        }

        return count - 1;
    }

    /**
     * Gets the value at a specified key.
     * Precondition: the values within the list are untouched.
     * Postcondition: the node designated by the key has its value(payload)
       returned as a String.
     * @param key - designates what position of node to read from.
     * @return - a string containing the payload of the designated node.
     * @throws Exception - throws Exception if key is not found.
     */
    public String getValue(int key) throws Exception {
        //the key must be 1 or higher
        if (key <= 0) {
            throw new Exception("Key is out of bounds");
        }
        Node current = first.next;//the next node from the default first node to be used
        for (int i = 1; i < key; i++) {
            if (current.next == null) {
                throw new Exception("Key not found");
            }
            current = current.next;
        }
        return current.payload;
    }

    /**
     * A toString method that overrides the default toString to display the 
       OrderedLinkedList values on separate lines.
     * Precondition: the values within the list are not displayed.
     * Postcondition: allows the list to be displayed in an ordered fashion.
     * @return - the string containing the lists contents.
     */
    @Override
    public String toString() {
        //initiates the String list
        String list = "";
        Node current = first.next; //the default first node to be used
        //while loop to loop all the way through the nodes
        while (current != null) {
            list = list + current.payload + "\n";//adds the current value to list
            current = current.next;
        }
        return "List: " + "\n" + list;
    }
}

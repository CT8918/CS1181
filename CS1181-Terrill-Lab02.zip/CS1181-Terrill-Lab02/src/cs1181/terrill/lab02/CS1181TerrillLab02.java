/*
 * Test class to test all the conditions that should work and should fail in the
   OrderedLinkedList class.
 */
package cs1181.terrill.lab02;

/**
 * @author Clayton Terrill 
 * CS1181L-06 
 * Instructor: R. Volkers 
 * TA: Sai Polamarasetty
 */
public class CS1181TerrillLab02 {

    /**
     * Test class that tests each class and its methods to see if it works when
       it should work, and fail when it should fail.
     * Precondition: OrderedLinkedList is untested.
     * Postcondition: OrderedLinkedList is either confirmed to work properly or
       confirmed to not work properly.
     * @param args the command line arguments
     * @throws java.lang.Exception - handles all Exceptions that may occur.
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
        
        //Node tests to see if lists is just working.
        OrderedLinkedList node = new OrderedLinkedList();
        node.insert("2", 2);
        node.insert("1", 1);
        node.insert("5", 5);
        node.insert("3", 3);
        node.insert("4", 4);
        System.out.println(node.toString());//prints out list. Proves toString works
        int listCount = node.listCount();//counts list
        //displays how many nodes are present
        System.out.println("Number of Nodes(should be 5): " + listCount);
                
        System.out.println("\n\n\nThe Following test should have an empty list\n"
                + "testing the emptyLis() method within the OrderedLinkedList class.\n"
                + "Should work properly: ");
        
        //test to see if empty class returns true. Should work
        try {
            OrderedLinkedList testList1 = new OrderedLinkedList();
            boolean test = testList1.empty();
            if (test = true){
                System.out.println("testList1 works properly");
            }else{
                System.out.println("testList1 failed"); 
            }
        } catch (Exception e) {
            System.out.println("testList1 failed");
        }
        
        System.out.println("\n\n\nThe Following test should not have an empty list\n"
                + "testing the emptyLis() method within the OrderedLinkedList class.\n"
                + "Should work properly:");
        
        //test to see if non empty class returns true. Should fail
        try {
            OrderedLinkedList testList2 = new OrderedLinkedList();
            testList2.insert("2", 2);
            testList2.insert("1", 1);
            testList2.insert("5", 5);
            testList2.insert("3", 3);
            testList2.insert("4", 4);
            boolean test = testList2.empty();
            if (test = true){
                System.out.println("testList2 works properly");
            }else{
                System.out.println("testList2 failed"); 
            }
        } catch (Exception e) {
            System.out.println("testList2 failed");
        }
        
        System.out.println("\n\n\nThe Following test for the getFirst() method \n"
                + "Should work properly: ");
        
        //test to see if the first value is actually returned. Should work properly
        try {
            OrderedLinkedList testList3 = new OrderedLinkedList();
            testList3.insert("2", 2);
            testList3.insert("1", 1);
            testList3.insert("5", 5);
            testList3.insert("3", 3);
            testList3.insert("4", 4);
            
            System.out.println(testList3.toString());
            String firstPayload = testList3.getFirst();
            System.out.println("Value returned: " + firstPayload);
            if(firstPayload == "1"){
                System.out.println("testList3 works properly");
            }else{
                System.out.println("testList3 failed");
            }
        } catch (Exception e) {
            System.out.println("testList3 failed");
        }
        
        System.out.println("\n\n\nThe Following test for the getFirst() method \n"
                + "Should fail: ");
        
        //test to see if the first node is empty, then it throws Exception. Should fail
        try {
            OrderedLinkedList testList4 = new OrderedLinkedList();
            testList4.getFirst();
            System.out.println("testList4 works properly");
        } catch (Exception e) {
            System.out.println("testList4 failed");
        }
        
        System.out.println("\n\n\nThe Following test for the getLast() method \n"
                + "Should work properly: ");
        
        //test to see if the first value is actually returned. Should work properly
        try {
            OrderedLinkedList testList5 = new OrderedLinkedList();
            testList5.insert("2", 2);
            testList5.insert("1", 1);
            testList5.insert("5", 5);
            testList5.insert("3", 3);
            testList5.insert("4", 4);
            
            System.out.println(testList5.toString());
            String firstPayload = testList5.getLast();
            System.out.println("Value returned: " + firstPayload);
            if(firstPayload == "5"){
                System.out.println("testList5 works properly");
            }else{
                System.out.println("testList5 failed");
            }
        } catch (Exception e) {
            System.out.println("testList5 failed");
        }
        
        System.out.println("\n\n\nThe Following test for the getLast() method \n"
                + "Should fail: ");
        
        //test to see if the last node is empty, then it throws Exception. Should fail
        try {
            OrderedLinkedList testList6 = new OrderedLinkedList();
            testList6.getLast();
            System.out.println("testList6 works properly");
        } catch (Exception e) {
            System.out.println("testList6 failed");
        }
        
        System.out.println("\n\n\nThe Following test for the insert() method \n"
                + "Should work properly: ");
        
        //test to see if the insert method inserts a wide range of keys, with values, in order. Should work properly
        try {
            OrderedLinkedList testList7 = new OrderedLinkedList();
            testList7.insert("2", 2);
            testList7.insert("1", 1);
            testList7.insert("5", 5);
            testList7.insert("3", 3);
            testList7.insert("4", 4);
            
            System.out.println(testList7.toString());
            System.out.println("testList7 works properly");
        } catch (Exception e) {
            System.out.println("testList7 failed");
        }
        
        System.out.println("\n\n\nThe Following test for the insert() method \n"
                + "Should fail: ");
        
        //test to see if the insert method fails when the same key value is used twice. Should fail
        try {
            OrderedLinkedList testList8 = new OrderedLinkedList();
            testList8.insert("2", 2);
            testList8.insert("1", 1);
            testList8.insert("5", 5);
            testList8.insert("3", 3);
            testList8.insert("3", 3);
            testList8.insert("4", 4);
            
            System.out.println(testList8.toString());
            System.out.println("testList8 works properly");
        } catch (Exception e) {
            System.out.println("testList8 failed");
        }
        
        System.out.println("\n\n\nThe Following test for the remove() method \n"
                + "Should work properly: ");
        
        //test to see if the remove method removes a value from the list. Should work properly
        try {
            OrderedLinkedList testList9 = new OrderedLinkedList();
            testList9.insert("2", 2);
            testList9.insert("1", 1);
            testList9.insert("5", 5);
            testList9.insert("3", 3);
            testList9.insert("4", 4);
            
            testList9.remove(3);
            
            System.out.println(testList9.toString());
            System.out.println("testList9 works properly");
        } catch (Exception e) {
            System.out.println("testList9 failed");
        }
        
        System.out.println("\n\n\nThe Following test for the remove() method \n"
                + "Should fail: ");
        
        //test to see if the remove method throws an Exception if key does not exitst. Should fail
        try {
            OrderedLinkedList testList10 = new OrderedLinkedList();
            testList10.insert("2", 2);
            testList10.insert("1", 1);
            testList10.insert("5", 5);
            testList10.insert("3", 3);
            testList10.insert("4", 4);
            
            testList10.remove(30);
            
            System.out.println(testList10.toString());
            System.out.println("testList10 works properly");
        } catch (Exception e) {
            System.out.println("testList10 failed");
        }
        
        System.out.println("\n\n\nThe Following test for the listCount() method \n"
                + "Should work properly: ");
        
        //test to see if the list count method returns the proper number. Should work properly
        try {
            OrderedLinkedList testList11 = new OrderedLinkedList();
            testList11.insert("2", 2);
            testList11.insert("1", 1);
            testList11.insert("5", 5);
            testList11.insert("3", 3);
            testList11.insert("4", 4);
            
            System.out.println(testList11.toString());
            
            int count = testList11.listCount();
            System.out.println("Number of nodes(Should be 5): " + count);
            if (count == 5){
                System.out.println("testList11 works properly");
            }else{
                System.out.println("testList11 failed");
            }
        } catch (Exception e) {
            System.out.println("testList11 failed");
        }
        
        System.out.println("\n\n\nThe Following test for the getValue() method \n"
                + "Should work properly: ");
        
        //test to see if the getValue() method returns the proper number. Should work properly
        try {
            OrderedLinkedList testList12 = new OrderedLinkedList();
            testList12.insert("2", 2);
            testList12.insert("1", 1);
            testList12.insert("5", 5);
            testList12.insert("3", 3);
            testList12.insert("4", 4);
            
            System.out.println(testList12.toString());
            
            String value = testList12.getValue(3);
            System.out.println("Value(Should be 3): " + value);
            if (value == "3"){
                System.out.println("testList12 works properly");
            }else{
                System.out.println("testList12 failed");
            }
        } catch (Exception e) {
            System.out.println("testList12 failed");
        }
        
        System.out.println("\n\n\nThe Following test for the getValue() method \n"
                + "Should fail: ");
        
        //test to see if the getValue() method is not within bounds. Should fail
        try {
            OrderedLinkedList testList13 = new OrderedLinkedList();
            
            String value = testList13.getValue(0);
            System.out.println("Value(Should be 3): " + value);
            if (value == "3"){
                System.out.println("testList13 works properly");
            }else{
                System.out.println("testList13 failed");
            }
        } catch (Exception e) {
            System.out.println("testList13 failed");
        }
        System.out.println("\n\n\nThe Following test for the getValue() method \n"
                + "Should fail: ");
        
        //test to see if the getValue() method throws Exception if key not found. Should fail
        try {
            OrderedLinkedList testList14 = new OrderedLinkedList();
            testList14.insert("2", 2);
            testList14.insert("1", 1);
            testList14.insert("5", 5);
            testList14.insert("3", 3);
            testList14.insert("4", 4);
            
            System.out.println(testList14.toString());
            
            testList14.getValue(6);
            
        } catch (Exception e) {
            System.out.println("testList14 failed");
        }
        
    }
    
}

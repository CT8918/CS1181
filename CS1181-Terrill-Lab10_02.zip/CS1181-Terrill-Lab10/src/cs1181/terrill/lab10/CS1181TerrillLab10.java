/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cs1181.terrill.lab10;

/**
 *
 * @author w020cdt
 */
public class CS1181TerrillLab10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ExpTree tree = new ExpTree("-1.11 2.22 + 4.44 -");
        System.out.println("\nValue of Expression Tree: " + tree.getValue());
        System.out.println("Height of Expression Tree: " + tree.getHeight());
        System.out.println("Returned Postfix Expression: " + tree.postfixTaversalStart());
        System.out.println("\nExpression Tree: ");
        tree.displayTree();
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cs1181.terrill.lab10;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

/**
 *
 * @author w020cdt
 */
public class ExpTree {

    private class tnode {

        String value;
        tnode left;
        tnode right;

        /**
         *
         * @param value - String value that the node holds in it.
         * @param left - left reference node.
         * @param right - right reference node.
         */
        public tnode(String value, tnode left, tnode right) {
            this.value = value;
            this.left = left;
            this.right = right;
        }
    }

    //the root node to act as a starting point.
    private tnode root;
    //stack to be used to create a Expression Tree.
    private Stack<tnode> stack;

    public ExpTree(String postfixExpression) {
        //stack to be used.
        this.stack = new Stack<>();
        //root to be intialized.
        this.root = null;

        //scanner to be used to get each token in the expression.
        Scanner exp = new Scanner(postfixExpression);

        //starting point to display original expression.
        System.out.print("Orignal Expression: ");

        //creates individual characters and push to stack.
        while (exp.hasNext()) {
            //token at the current position.
            String token = exp.next();
            System.out.print(token + " ");
            //if operator, then pop two tokens.
            if (token.equals("*") || token.equals("/") || token.equals("+") || token.equals("-")) {
                //pops right side of stack.
                tnode right = stack.pop();
                //pops left side of stack.
                tnode left = stack.pop();
                //adds a parent node.
                stack.push(new tnode(token, left, right));
            } //if it is a positive or negative value, add a node to stack.
            else {
                stack.add(new tnode(token, null, null));
            }
        }

        //puts the top of the stack in as root. Allows access to tree.
        root = stack.pop();
    }

    /**
     * Begins the process of finding the height of the Expression Tree then
     * calls the recursive part to find the height of the Expression Tree.
     *
     * @return - the total height of the tree
     */
    public String getHeight() {
        //StringBuilder used to determine the height.
        StringBuilder heightBuilder = new StringBuilder();
        //appends value of height using the recursive part.
        heightBuilder.append(recursiveHeight(root));
        //returns the StringBuilder as a String.
        return heightBuilder.toString();
    }

    /**
     * Recursive part to find the height of the Expression Tree.
     *
     * @param current- current node being looked at.
     * @return - the current height of the tree.
     */
    public int recursiveHeight(tnode current) {
        //ends the traversal when the current node is null.
        if (current == null) {
            return 0;
        }

        //recursive calls to traverse.
        int left = recursiveHeight(current.left);
        int right = recursiveHeight(current.right);

        //determines which way to go.
        return left > right ? left + 1 : right + 1;
    }

    /**
     * Begins the process of finding the postfix expression of the 
     * Expression Tree then calls the recursive part to find the postfix 
     * expression of the Expression Tree.
     *
     * @return - the full postfix expression
     */
    public String postfixTaversalStart() {
        //stringbuilder to build the expression.
        StringBuilder expressionBuilder = new StringBuilder();

        //calls the recursive part to get the postfix
        postfixTraversalRecursively(root, expressionBuilder);

        //the string builder containing the expression returns as a string.
        return expressionBuilder.toString();
    }

    /**
     * The recursive part to find the postfix expression of the Expression Tree.
     *
     * @param current - current node being looked at.
     * @param expressionBuilder - string builder to create expression.
     */
    public void postfixTraversalRecursively(tnode current, StringBuilder expressionBuilder) {
        //ends the traversal when the current node is null.
        if (current == null) {
            return;
        }

        //recursive calls to traverse the tree.
        postfixTraversalRecursively(current.left, expressionBuilder);
        postfixTraversalRecursively(current.right, expressionBuilder);

        //adds the current value to the expression and then spaces it from the next.
        expressionBuilder.append(current.value).append(" ");
    }
    
    /**
     * Calls the recursive function that gets the total value of the expression.
     * @return - the value that the Expression Tree porduces.
     */
    public double getValue()
    {
        //calls the recursive part.
        return getValueRecursively(root);
    }

    /**
     * The recursive part of getValue() to find the value of the Expression Tree.
     * @param current - current node being looked at.
     * @return - the calculated value of the Expression Tree.
     */
    private double getValueRecursively(tnode current)
    {
        //if a leaf is found, then that is a value.
        if (current.left == null && current.right == null)
        {
            //get the value.
            return Double.parseDouble(current.value);
        }

        //if not then get the left and right value and perform the current operator
        double leftValue = getValueRecursively(current.left);
        double rightValue = getValueRecursively(current.right);

        //switch statement to determine what operator is being used. Then conducts operation.
        switch (current.value)
        {
            //addition case adds the left and right values.
            case "+":
                return leftValue + rightValue;
            //subtraction case subtracts the left and right values.
            case "-":
                return leftValue - rightValue;
            //multiplication case multiplies the left and right values.
            case "*":
                return leftValue * rightValue;
            //the default case prevents a return value being needed after switch.
            //dividing case divides the left and right values.    
            default:
                return leftValue / rightValue;
        }
    }
    /**
     * Prints out the tree by level.
     */
    public void displayTree()
    {
        //if the ExpressionTree is empty then a message of emptiness is displayed.
        if (root == null)
        {
            System.out.println("List is empty.");
        }
        else
        {
            //creates a list of levels which contain all tree nodes in that level
            LinkedList<ArrayList<tnode>> currentTreeLevelList = new LinkedList<>();
            
            //creates a queue of tree nodes as a linked list which act as the levels
            Queue<tnode> treeNodeQueue = new LinkedList<>();
            
            //root added to the queue
            treeNodeQueue.add(root);
            
            //runs until the treeNodeQueue is empty.
            while (!treeNodeQueue.isEmpty())
            {
                //each level is created and added.
                ArrayList<tnode> currentTreeLevel = new ArrayList<>(treeNodeQueue.size());
                currentTreeLevelList.add(currentTreeLevel);
                for (tnode treeNode : new ArrayList<>(treeNodeQueue))
                {
                    currentTreeLevel.add(treeNode);
                    
                    //looks at the left child node.
                    if (treeNode.left != null)
                    {
                        treeNodeQueue.add(treeNode.left);
                    }
                    //looks at the right child node.
                    if (treeNode.right != null)
                    {
                        treeNodeQueue.add(treeNode.right);
                    }
                    //tries to remove the root of the node.
                    try
                    {
                        treeNodeQueue.remove();
                    } catch (Exception e)
                    {
                        throw e;
                    }
                }
            }
            
            //prints the levels
            int level = 1; //current level.
            for (ArrayList<tnode> currentTreeLevel : currentTreeLevelList)
            {
                //prints out the current level and then its contents.
                System.out.print("Level " + level + ": ");
                for (tnode node : currentTreeLevel)
                {
                    //prints out every value in level.
                    System.out.print(node.value + " ");
                }
                //goes to the next level.
                level++;
                //goes to next line.
                System.out.println();
            }
        }
    }
}

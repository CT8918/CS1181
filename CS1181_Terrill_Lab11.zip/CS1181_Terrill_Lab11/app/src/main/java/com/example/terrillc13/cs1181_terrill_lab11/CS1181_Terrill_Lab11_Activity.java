package com.example.terrillc13.cs1181_terrill_lab11;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class CS1181_Terrill_Lab11_Activity extends AppCompatActivity {

    //String to define log outputs
    private String TAG = "convertTempLogs";
    //Finds temperature.
    private TextView temperature;
    private String stringTemperature = null;
    private double doubleTemperature;
    private TextView convertedTemperature;
    //The scale designators.
    private String inputScale = "none";
    private String outputScale = "none";
    //RadioButton(s) to listen for.
    private RadioButton inCelsiusButton, inFahrenheitButton, inKelvinButton;
    private RadioButton outCelsiusButton, outFahrenheitButton, outKelvinButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cs1181__terrill__lab11_);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //adds a log statement
        Log.i(TAG, "In OnCreate");

        //initialize and get variables.
        temperature = (TextView) findViewById(R.id.inTemperature);

        convertedTemperature = (TextView) findViewById(R.id.outTemperature);

        //the buttons
        inCelsiusButton = (RadioButton) findViewById(R.id.inCelsius);
        inFahrenheitButton = (RadioButton) findViewById(R.id.inFahrenheit);
        inKelvinButton = (RadioButton) findViewById(R.id.inKelvin);
        outCelsiusButton = (RadioButton) findViewById(R.id.outCelsius);
        outFahrenheitButton = (RadioButton) findViewById(R.id.outFahrenheit);
        outKelvinButton = (RadioButton) findViewById(R.id.outKelvin);


        //here by default
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_cs1181__terrill__lab11_, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    protected void onPause() {
        super.onPause();
        Log.i(TAG, "In OnPause");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i(TAG, "In OnResume");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i(TAG, "In OnRestart");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i(TAG, "In OnStart");
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.i(TAG, "In OnSaveInstanceState");
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Log.i(TAG, "In OnRestoreInstanceState");
    }

    /**
     * When the input text box is clicked or entered into, this runs. Sets a temperature value,
     * then runs the conversion.
     * Precondition - Must be clicked and app must be running.
     * Postcondition - The temperature variables have been set and conversion has been run.
     * @param view - the view.
     */
    public void inTemperatureClicked(View view) {
        Log.i(TAG, "In inTemperatureClicked");

        //read value inputted
        stringTemperature = temperature.getText().toString();
        if(stringTemperature == null || stringTemperature.equals("")){
            //displayToast();
            return;
        }
        //convert value to double
        doubleTemperature = Double.parseDouble(stringTemperature);
        Log.i(TAG, stringTemperature);
        convertedTemperature.setText(Double.toString(doubleTemperature));
        runConversion();
    }

    /**
     * Runs when any of the radio buttons within the radio group is clicked. Must be double
     * clicked initially due to confirmation of group being clicked.
     * Precondition - The user input field must contain a valid number.
     * Postcondition - The state of the conversion and its variables have been updated and ran.
     * @param view - the view.
     */
    public void onInputScaleClicked(View view) {
        //check as soon as group is clicked that the temperature has been entered. Displays Toast if not.
        if(stringTemperature == null){
            displayToast();
        }
        //listens for when the celsius button is clicked.
        inCelsiusButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //checks to see if the input is there or not. Displays toast if not.
                if(stringTemperature == null){
                    displayToast();
                }
                //sets other two button to false
                inFahrenheitButton.setChecked(false);
                inKelvinButton.setChecked(false);
                //sets the type of conversion variable
                inputScale = "celsius";
                Log.i(TAG, "In inCelsiusClicked");
                runConversion();
            }
        });
        //listens for when the fahrenheit button is clicked.
        inFahrenheitButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //checks to see if the input is there or not. Displays toast if not.
                if (stringTemperature == null) {
                    displayToast();
                }
                //sets other two button to false
                inCelsiusButton.setChecked(false);
                inKelvinButton.setChecked(false);
                //sets the type of conversion variable
                inputScale = "fahrenheit";
                Log.i(TAG, "In inFahrenheitClicked");
                runConversion();
            }
        });
        //listens for when the kelvin button is clicked.
        inKelvinButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //checks to see if the input is there or not. Displays toast if not.
                if (stringTemperature == null) {
                    displayToast();
                }
                //sets other two button to false
                inFahrenheitButton.setChecked(false);
                inCelsiusButton.setChecked(false);
                //sets the type of conversion variable
                inputScale = "kelvin";
                Log.i(TAG, "In inKelvinClicked");
                runConversion();
            }
        });
    }

    /**
     * Runs when any of the radio buttons within the radio group is clicked. Must be double
     * clicked initially due to confirmation of group being clicked.
     * Precondition - The user input field must contain a valid number.
     * Postcondition - The state of the conversion and its variables have been updated and ran.
     * @param view - the view.
     */
    public void onOutputScaleClicked(View view) {
        //check as soon as group is clicked that the temperature has been entered. Displays Toast if not.
        if(stringTemperature == null){
            displayToast();
        }

        //listens for when the celsius button is clicked.
        outCelsiusButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //checks to see if the input is there or not. Displays toast if not.
                if(stringTemperature == null){
                    displayToast();
                }
                //sets other two button to false
                outFahrenheitButton.setChecked(false);
                outKelvinButton.setChecked(false);
                //sets the type of conversion variable
                outputScale = "celsius";
                Log.i(TAG, "In outCelsiusClicked");
                runConversion();
            }
        });
        //listens for when the fahrenheit button is clicked.
        outFahrenheitButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //checks to see if the input is there or not. Displays toast if not.
                if (stringTemperature == null) {
                    displayToast();
                }
                //sets other two button to false
                outCelsiusButton.setChecked(false);
                outKelvinButton.setChecked(false);
                //sets the type of conversion variable
                outputScale = "fahrenheit";
                Log.i(TAG, "In outFahrenheitClicked");
                runConversion();
            }
        });
        //listens for when the kelvin button is clicked.
        outKelvinButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //checks to see if the input is there or not. Displays toast if not.
                if (stringTemperature == null) {
                    displayToast();
                }
                //sets other two button to false
                outFahrenheitButton.setChecked(false);
                outCelsiusButton.setChecked(false);
                //sets the type of conversion variable
                outputScale = "kelvin";
                Log.i(TAG, "In outKelvinClicked");
                runConversion();
            }
        });
    }

    /**
     * Method to run the conversion based on the temperature entered and the state of the
     * inputScale and outputScale variables.
     * Precondition - A value must be present to convert. Button scales must also be checked\
     * in order to run proper conversion.
     * Postcondition - The conversion has been ran and the proper conversion applied and displayed.
     */
    public void runConversion(){
        double doubleConvertedTemperature;
        //Log.i(TAG, "In runConversion");
        if(inputScale == "celsius" && outputScale == "fahrenheit") {
            Log.i(TAG, "Celsius to Fahrenheit conversion");
            doubleConvertedTemperature = ((double)doubleTemperature * (double)(9.0/5.0) + 32);
            //convertedTemperature.setText(Double.toString(doubleConvertedTemperature));
        }
        else if(inputScale == "celsius" && outputScale == "kelvin"){
            Log.i(TAG, "Celsius to Kelvin conversion");
            doubleConvertedTemperature = ((double)doubleTemperature + 273.15);
            //convertedTemperature.setText(Double.toString(doubleConvertedTemperature));
        }
        else if(inputScale == "fahrenheit" && outputScale == "celsius"){
            Log.i(TAG, "Fahrenheit to Celsius conversion");
            doubleConvertedTemperature = (((double)doubleTemperature - 32) * (double)(5.0/9.0));
            //convertedTemperature.setText(Double.toString(doubleConvertedTemperature));
        }
        else if(inputScale == "fahrenheit" && outputScale == "kelvin"){
            Log.i(TAG, "Fahrenheit to Kelvin conversion");
            doubleConvertedTemperature = ((((double)doubleTemperature - 32) * (double)(5.0/9.0)) + 273.15);
            //convertedTemperature.setText(Double.toString(doubleConvertedTemperature));
        }
        else if(inputScale == "kelvin" && outputScale == "fahrenheit"){
            Log.i(TAG, "Kelvin to Fahrenheit conversion");
            doubleConvertedTemperature = ((((double)doubleTemperature - 273.15) * (double)(9.0/5.0)) + 32);
            //convertedTemperature.setText(Double.toString(doubleConvertedTemperature));
        }
        else if(inputScale == "kelvin" && outputScale == "celsius"){
            Log.i(TAG, "Kelvin to Celsius conversion");
            doubleConvertedTemperature = ((double)doubleTemperature - 273.15);
            //convertedTemperature.setText(Double.toString(doubleConvertedTemperature));
        }
        else{
            doubleConvertedTemperature= doubleTemperature;
            Log.i(TAG, "No conversion took place");
        }
        double roundedConvertedTemperature = Math.round (doubleConvertedTemperature * 100.0) / 100.0;
        convertedTemperature.setText(Double.toString(roundedConvertedTemperature));
    }

    /**
     * Displays a Toast telling the user that a value must be entered.
     * Precondition - The displayToast() must be called when the value field is null.
     * Postcondition - App continues to run, allowing the user to input a number.
     */
    public void displayToast(){
        Context context = getApplicationContext();
        //sets the Toast text
        CharSequence text = "                Please Enter A Value\n" +
                "Then Double Click on Options to Choose";
        //sets how long the Toast appears.
        int duration = Toast.LENGTH_LONG;

        //creates the Toast.
        Toast toast = Toast.makeText(context, text, duration);
        //sets where the Toast will appear.
        toast.setGravity(Gravity.CENTER| Gravity.CENTER, 0, 0);
        //displays the Toast.
        toast.show();
    }
}
